# Check times

|package      |version | check_time|
|:------------|:-------|----------:|
|healthcareai |0.1.12  |       62.7|
|implyr       |0.1.0   |       16.7|


