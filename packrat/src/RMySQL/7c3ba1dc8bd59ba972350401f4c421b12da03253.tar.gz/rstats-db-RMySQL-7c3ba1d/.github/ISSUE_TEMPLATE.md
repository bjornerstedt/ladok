IMPORTANT: the RMySQL package is being phased out and replaced by the RMariaDB package. All development is now focused on RMariaDB; the RMySQL package will only minimal maintenance. 

Please consider migrating to RMariaDB and open new bugs and feature requests in the RMariaDB repository.
